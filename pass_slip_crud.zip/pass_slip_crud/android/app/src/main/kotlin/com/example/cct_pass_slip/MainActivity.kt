package com.example.cct_pass_slip

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
