package com.example.pass_slip_crud

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
