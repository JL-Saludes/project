# CCT Pass Slip Management and Monitoring System

Flutter + Firebase (Auth + Cloud Firestore). Users: **Faculty**, **Authorized Personnel**, **Guard**.
Students have no accounts and never use the app.

## Setup
```bash
cd cct_pass_slip
flutter create .                 # generates android/ios/web folders (keeps lib/ & pubspec)
flutter pub get
dart pub global activate flutterfire_cli
flutterfire configure            # overwrites lib/firebase_options.dart
firebase deploy --only firestore:rules,firestore:indexes
```
In the Firebase console enable **Authentication → Email/Password** and create the **Firestore** database.
If `flutter create` generated `test/widget_test.dart`, delete it (it references the default `MyApp`).

## Create users (clients cannot write `users/`, by design)
Easiest: `npm i firebase-admin` then
`GOOGLE_APPLICATION_CREDENTIALS=serviceAccount.json node scripts/seed_users.js`
(creates `faculty@cct.test`, `personnel@cct.test`, `guard@cct.test`).

Manual: create the user in Authentication, then add `users/{uid}` with
`uid, fullName, email, role (FACULTY | AUTHORIZED_PERSONNEL | GUARD), facultyId, createdAt`.

## Behaviour notes
- Status flow: PENDING → APPROVED/REJECTED → OUT → RETURNED (CANCELLED from PENDING/APPROVED). Enforced in the service layer (transactions) AND in `firestore.rules`.
- OVERDUE = status OUT and expected return passed. Computed for display only; never stored.
- Guards can only time-out a slip dated **today**.
- Faculty "Cancel" = soft cancel (status CANCELLED). "Delete" permanently removes only CANCELLED slips (faculty) or CANCELLED/REJECTED slips (personnel). Both are confirmed and logged.
- Duplicate protection: a faculty member cannot create/edit a slip for the same student whose time window overlaps another active slip.
- Edit program/year lists in `lib/utils/constants.dart`.
