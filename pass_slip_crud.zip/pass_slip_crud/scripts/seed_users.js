// Creates the 3 demo users (Auth + users/{uid} profile in Firestore).
// Run from the project root:  node scripts/seed_users.js
const path = require('path');
const { initializeApp, cert } = require('firebase-admin/app');
const { getAuth } = require('firebase-admin/auth');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');

const serviceAccount = require(path.resolve(__dirname, '..', 'serviceAccount.json'));
initializeApp({ credential: cert(serviceAccount) });

const auth = getAuth();
const db = getFirestore();

const users = [
  { email: 'faculty@cct.test',   password: 'Faculty123!',   fullName: 'Juan Dela Cruz', role: 'FACULTY',              facultyId: 'FAC-001' },
  { email: 'personnel@cct.test', password: 'Personnel123!', fullName: 'Maria Santos',   role: 'AUTHORIZED_PERSONNEL', facultyId: '' },
  { email: 'guard@cct.test',     password: 'Guard123!',     fullName: 'Pedro Reyes',    role: 'GUARD',                facultyId: '' },
];

(async () => {
  try {
    for (const u of users) {
      let rec;
      try {
        rec = await auth.getUserByEmail(u.email);
      } catch {
        rec = await auth.createUser({
          email: u.email,
          password: u.password,
          displayName: u.fullName,
        });
      }
      await db.collection('users').doc(rec.uid).set({
        uid: rec.uid,
        fullName: u.fullName,
        email: u.email,
        role: u.role,
        facultyId: u.facultyId,
        createdAt: FieldValue.serverTimestamp(),
      });
      console.log('Ready:', u.email, '→', u.role);
    }
    console.log('Done.');
  } catch (e) {
    console.error('Seeding failed:', e.message);
    process.exit(1);
  }
})();