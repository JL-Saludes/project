import 'package:cloud_firestore/cloud_firestore.dart';
import '../utils/constants.dart';
import '../utils/formatters.dart';

/// Values entered by the faculty/personnel in the create/edit form.
class PassSlipForm {
  final String studentId;
  final String studentName;
  final String program;
  final String yearLevel;
  final String purpose;
  final String destination;
  final DateTime date;
  final DateTime authorizedTimeOut;
  final DateTime expectedReturnTime;
  final String remarks;

  PassSlipForm({
    required String studentId,
    required this.studentName,
    required this.program,
    required this.yearLevel,
    required this.purpose,
    required this.destination,
    required this.date,
    required this.authorizedTimeOut,
    required this.expectedReturnTime,
    required this.remarks,
  }) : studentId = studentId.trim().toUpperCase();

  /// Only the user-editable fields (matches `editableKeys()` in the rules).
  Map<String, dynamic> toMap() => {
        'studentId': studentId,
        'studentName': studentName.trim(),
        'program': program,
        'yearLevel': yearLevel,
        'purpose': purpose.trim(),
        'destination': destination.trim(),
        'date': Timestamp.fromDate(dayOnly(date)),
        'authorizedTimeOut': Timestamp.fromDate(authorizedTimeOut),
        'expectedReturnTime': Timestamp.fromDate(expectedReturnTime),
        'remarks': remarks.trim(),
      };
}

/// Thin typed wrapper over a pass_slips document.
class PassSlipModel {
  final Map<String, dynamic> _d;
  PassSlipModel.fromMap(Map<String, dynamic> data) : _d = data;

  String _s(String k) => (_d[k] as String?) ?? '';
  String? _so(String k) {
    final v = _d[k] as String?;
    return (v == null || v.isEmpty) ? null : v;
  }

  DateTime? _t(String k) {
    final v = _d[k];
    return v is Timestamp ? v.toDate() : null;
  }

  static final _epoch = DateTime.fromMillisecondsSinceEpoch(0);

  String get passSlipId => _s('passSlipId');
  String get studentId => _s('studentId');
  String get studentName => _s('studentName');
  String get program => _s('program');
  String get yearLevel => _s('yearLevel');
  String get purpose => _s('purpose');
  String get destination => _s('destination');
  String get remarks => _s('remarks');
  String get status => _s('status');

  DateTime get date => _t('date') ?? _epoch;
  DateTime get authorizedTimeOut => _t('authorizedTimeOut') ?? _epoch;
  DateTime get expectedReturnTime => _t('expectedReturnTime') ?? _epoch;
  DateTime? get actualTimeOut => _t('actualTimeOut');
  DateTime? get actualTimeIn => _t('actualTimeIn');

  String get createdBy => _s('createdBy');
  String get createdByName => _s('createdByName');
  DateTime? get createdAt => _t('createdAt');
  DateTime? get updatedAt => _t('updatedAt');

  String? get approvedBy => _so('approvedBy');
  String? get approvedByName => _so('approvedByName');
  DateTime? get approvedAt => _t('approvedAt');

  String? get rejectedBy => _so('rejectedBy');
  String? get rejectedByName => _so('rejectedByName');
  DateTime? get rejectedAt => _t('rejectedAt');
  String? get rejectionReason => _so('rejectionReason');

  String? get timeOutVerifiedByName => _so('timeOutVerifiedByName');
  DateTime? get timeOutVerifiedAt => _t('timeOutVerifiedAt');
  String? get timeInVerifiedByName => _so('timeInVerifiedByName');
  DateTime? get timeInVerifiedAt => _t('timeInVerifiedAt');

  /// OVERDUE is computed, never stored.
  bool get isOverdue =>
      status == Status.out && DateTime.now().isAfter(expectedReturnTime);

  bool matchesQuery(String q) {
    final n = q.trim().toLowerCase();
    if (n.isEmpty) return true;
    return passSlipId.toLowerCase().contains(n) ||
        studentId.toLowerCase().contains(n) ||
        studentName.toLowerCase().contains(n) ||
        createdByName.toLowerCase().contains(n);
  }

  bool matchesStatus(String? filter) {
    if (filter == null) return true;
    if (filter == Status.overdue) return isOverdue;
    return status == filter;
  }
}
