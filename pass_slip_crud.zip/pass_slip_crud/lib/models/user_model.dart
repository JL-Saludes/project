import 'package:cloud_firestore/cloud_firestore.dart';
import '../utils/constants.dart';

class UserModel {
  final String uid;
  final String fullName;
  final String email;
  final String role;
  final String facultyId;
  final DateTime? createdAt;

  const UserModel({
    required this.uid,
    required this.fullName,
    required this.email,
    required this.role,
    this.facultyId = '',
    this.createdAt,
  });

  bool get hasValidRole => Roles.all.contains(role);

  factory UserModel.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data() ?? {};
    final created = d['createdAt'];
    return UserModel(
      uid: (d['uid'] as String?) ?? doc.id,
      fullName: (d['fullName'] as String?) ?? '',
      email: (d['email'] as String?) ?? '',
      role: (d['role'] as String?) ?? '',
      facultyId: (d['facultyId'] as String?) ?? '',
      createdAt: created is Timestamp ? created.toDate() : null,
    );
  }
}
