import 'package:cloud_firestore/cloud_firestore.dart';

class ActivityLogModel {
  final String id;
  final String action;
  final String passSlipId;
  final String performedBy;
  final String performedByName;
  final String userRole;
  final DateTime? timestamp;
  final String description;

  const ActivityLogModel({
    required this.id,
    required this.action,
    required this.passSlipId,
    required this.performedBy,
    required this.performedByName,
    required this.userRole,
    required this.timestamp,
    required this.description,
  });

  factory ActivityLogModel.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data() ?? {};
    final ts = d['timestamp'];
    return ActivityLogModel(
      id: doc.id,
      action: (d['action'] as String?) ?? '',
      passSlipId: (d['passSlipId'] as String?) ?? '',
      performedBy: (d['performedBy'] as String?) ?? '',
      performedByName: (d['performedByName'] as String?) ?? '',
      userRole: (d['userRole'] as String?) ?? '',
      timestamp: ts is Timestamp ? ts.toDate() : null,
      description: (d['description'] as String?) ?? '',
    );
  }
}
