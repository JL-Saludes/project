import 'package:flutter/material.dart';
import '../utils/constants.dart';

class StatusBadge extends StatelessWidget {
  final String status;
  final bool overdue;
  const StatusBadge({super.key, required this.status, this.overdue = false});

  Widget _pill(String s) {
    final c = Status.color(s);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: c.withAlpha(30),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: c.withAlpha(120)),
      ),
      child: Text(s,
          style: TextStyle(
              color: c, fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: .4)),
    );
  }

  @override
  Widget build(BuildContext context) => Wrap(
        spacing: 6,
        runSpacing: 4,
        children: [_pill(status), if (overdue) _pill(Status.overdue)],
      );
}
