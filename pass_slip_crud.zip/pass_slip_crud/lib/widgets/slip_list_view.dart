import 'package:flutter/material.dart';
import '../models/pass_slip_model.dart';
import '../utils/app_exception.dart';
import '../utils/constants.dart';
import '../utils/formatters.dart';
import 'loading_widget.dart';
import 'pass_slip_card.dart';

/// Reusable searchable / filterable list. The stream is created by
/// [streamFactory] inside this widget's State, so it is owned (and disposed)
/// by the list and never listened to twice.
class SlipListView extends StatefulWidget {
  final Stream<List<PassSlipModel>> Function() streamFactory;
  final void Function(PassSlipModel) onTap;
  final Widget? Function(PassSlipModel)? actionsBuilder;
  final List<String> filters;
  final bool dateFilter;
  final bool detailed;
  final bool showFaculty;
  final bool autofocus;
  final String searchHint;
  final String emptyTitle;
  final String emptyMessage;
  final int Function(PassSlipModel, PassSlipModel)? sort;
  final Widget Function(List<PassSlipModel> all)? headerBuilder;

  const SlipListView({
    super.key,
    required this.streamFactory,
    required this.onTap,
    this.actionsBuilder,
    this.filters = const [],
    this.dateFilter = false,
    this.detailed = false,
    this.showFaculty = true,
    this.autofocus = false,
    this.searchHint = 'Search by slip ID, student ID or name',
    this.emptyTitle = 'No pass slips found',
    this.emptyMessage = 'Try a different search or filter.',
    this.sort,
    this.headerBuilder,
  });

  @override
  State<SlipListView> createState() => _SlipListViewState();
}

class _SlipListViewState extends State<SlipListView> {
  late final Stream<List<PassSlipModel>> _stream = widget.streamFactory();
  String _query = '';
  String? _filter;
  DateTime? _date;

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final d = await showDatePicker(
      context: context,
      initialDate: _date ?? now,
      firstDate: DateTime(now.year - 2),
      lastDate: DateTime(now.year + 2),
    );
    if (d != null) setState(() => _date = d);
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 900),
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: TextField(
              autofocus: widget.autofocus,
              onChanged: (v) => setState(() => _query = v),
              decoration: InputDecoration(
                hintText: widget.searchHint,
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _query.isEmpty
                    ? null
                    : const Icon(Icons.filter_alt_outlined, size: 18),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
          if (widget.filters.isNotEmpty || widget.dateFilter)
            SizedBox(
              height: 48,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                children: [
                  if (widget.filters.isNotEmpty) ...[
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: ChoiceChip(
                        label: const Text('All'),
                        selected: _filter == null,
                        onSelected: (_) => setState(() => _filter = null),
                      ),
                    ),
                    for (final f in widget.filters)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: ChoiceChip(
                          label: Text(Status.label(f)),
                          selected: _filter == f,
                          onSelected: (_) => setState(
                              () => _filter = _filter == f ? null : f),
                        ),
                      ),
                  ],
                  if (widget.dateFilter)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: InputChip(
                        avatar: const Icon(Icons.calendar_today, size: 16),
                        label: Text(_date == null ? 'Any date' : fmtDate(_date)),
                        onPressed: _pickDate,
                        onDeleted:
                            _date == null ? null : () => setState(() => _date = null),
                      ),
                    ),
                ],
              ),
            ),
          Expanded(
            child: StreamBuilder<List<PassSlipModel>>(
              stream: _stream,
              builder: (context, snap) {
                if (snap.hasError) {
                  return EmptyState(
                    icon: Icons.error_outline,
                    title: 'Unable to load pass slips',
                    message: friendlyError(snap.error!,
                        fallback:
                            'Unable to load pass slips. Please check your connection and try again.'),
                  );
                }
                if (!snap.hasData) {
                  return const LoadingWidget(message: 'Loading pass slips…');
                }
                final all = snap.data!;
                final list = all
                    .where((s) =>
                        s.matchesQuery(_query) &&
                        s.matchesStatus(_filter) &&
                        (_date == null || isSameDay(s.date, _date!)))
                    .toList();
                if (widget.sort != null) list.sort(widget.sort);

                return Column(children: [
                  if (widget.headerBuilder != null) widget.headerBuilder!(all),
                  Expanded(
                    child: list.isEmpty
                        ? EmptyState(
                            icon: Icons.assignment_outlined,
                            title: all.isEmpty
                                ? widget.emptyTitle
                                : 'No matching results',
                            message: all.isEmpty
                                ? null
                                : widget.emptyMessage,
                          )
                        : ListView.builder(
                            padding: const EdgeInsets.fromLTRB(16, 4, 16, 90),
                            itemCount: list.length,
                            itemBuilder: (_, i) {
                              final s = list[i];
                              return PassSlipCard(
                                slip: s,
                                detailed: widget.detailed,
                                showFaculty: widget.showFaculty,
                                onTap: () => widget.onTap(s),
                                actions: widget.actionsBuilder?.call(s),
                              );
                            },
                          ),
                  ),
                ]);
              },
            ),
          ),
        ]),
      ),
    );
  }
}
