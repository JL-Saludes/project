import 'package:flutter/material.dart';
import '../models/pass_slip_model.dart';
import '../utils/constants.dart';
import '../utils/formatters.dart';
import 'status_badge.dart';

class PassSlipCard extends StatelessWidget {
  final PassSlipModel slip;
  final VoidCallback? onTap;
  final Widget? actions;
  final bool detailed;
  final bool showFaculty;

  const PassSlipCard({
    super.key,
    required this.slip,
    this.onTap,
    this.actions,
    this.detailed = false,
    this.showFaculty = true,
  });

  @override
  Widget build(BuildContext context) {
    final overdue = slip.isOverdue;
    return Card(
      elevation: 1,
      margin: const EdgeInsets.symmetric(vertical: 6),
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(
            color: overdue ? Status.color(Status.overdue) : Colors.transparent,
            width: 1.5),
      ),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(
                child: Text(slip.passSlipId,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 13)),
              ),
              const SizedBox(width: 8),
              StatusBadge(status: slip.status, overdue: overdue),
            ]),
            const SizedBox(height: 8),
            Text(slip.studentName,
                style: Theme.of(context)
                    .textTheme
                    .titleMedium
                    ?.copyWith(fontWeight: FontWeight.bold)),
            Text('${slip.studentId} • ${slip.program} • ${slip.yearLevel}',
                style: TextStyle(color: Colors.grey.shade700, fontSize: 12)),
            const Divider(height: 20),
            _Info(Icons.edit_note, 'Purpose', slip.purpose),
            _Info(Icons.place_outlined, 'Destination', slip.destination),
            _Info(Icons.event, 'Date', fmtDate(slip.date)),
            _Info(Icons.schedule, 'Time-Out → Return',
                '${fmtTime(slip.authorizedTimeOut)} → ${fmtTime(slip.expectedReturnTime)}'),
            if (showFaculty)
              _Info(Icons.person_outline, 'Faculty', slip.createdByName),
            if (detailed) ...[
              if (slip.remarks.isNotEmpty)
                _Info(Icons.notes, 'Remarks', slip.remarks),
              if (slip.actualTimeOut != null)
                _Info(Icons.logout, 'Actual time out',
                    fmtDateTime(slip.actualTimeOut)),
              if (slip.actualTimeIn != null)
                _Info(Icons.login, 'Actual time in',
                    fmtDateTime(slip.actualTimeIn)),
              if (slip.timeOutVerifiedByName != null)
                _Info(Icons.security, 'Guard', slip.timeOutVerifiedByName!),
            ],
            if (actions != null)
              Padding(padding: const EdgeInsets.only(top: 10), child: actions),
          ]),
        ),
      ),
    );
  }
}

class _Info extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  const _Info(this.icon, this.label, this.value);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, size: 16, color: Colors.grey.shade600),
          const SizedBox(width: 8),
          Expanded(
            child: Text.rich(TextSpan(children: [
              TextSpan(
                  text: '$label: ',
                  style: TextStyle(color: Colors.grey.shade700, fontSize: 13)),
              TextSpan(
                  text: value.isEmpty ? '—' : value,
                  style: const TextStyle(
                      fontWeight: FontWeight.w500, fontSize: 13)),
            ])),
          ),
        ]),
      );
}
