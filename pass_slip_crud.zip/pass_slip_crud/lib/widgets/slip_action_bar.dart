import 'package:flutter/material.dart';
import '../models/pass_slip_model.dart';
import '../models/user_model.dart';
import '../screens/faculty/create_pass_slip.dart';
import '../utils/constants.dart';
import '../utils/slip_actions.dart';

enum _A { approve, reject, edit, cancel, delete, timeOut, timeIn }

/// Shows only the buttons the current user may use on this slip, given its
/// current status. (Firestore rules enforce the same restrictions.)
class SlipActionBar extends StatelessWidget {
  final UserModel user;
  final PassSlipModel slip;
  final VoidCallback? onDeleted;
  const SlipActionBar(
      {super.key, required this.user, required this.slip, this.onDeleted});

  static List<_A> _available(UserModel u, PassSlipModel s) {
    switch (u.role) {
      case Roles.faculty:
        if (s.createdBy != u.uid) return [];
        if (s.status == Status.pending) return [_A.edit, _A.cancel];
        if (s.status == Status.approved) return [_A.cancel];
        if (s.status == Status.cancelled) return [_A.delete];
        return [];
      case Roles.personnel:
        if (s.status == Status.pending) {
          return [_A.approve, _A.reject, _A.edit, _A.cancel];
        }
        if (s.status == Status.approved) return [_A.edit, _A.cancel];
        if (s.status == Status.cancelled || s.status == Status.rejected) {
          return [_A.delete];
        }
        return [];
      case Roles.guard:
        if (s.status == Status.approved) return [_A.timeOut];
        if (s.status == Status.out) return [_A.timeIn];
        return [];
      default:
        return [];
    }
  }

  static bool hasActions(UserModel u, PassSlipModel s) =>
      _available(u, s).isNotEmpty;

  @override
  Widget build(BuildContext context) {
    final acts = _available(user, slip);
    if (acts.isEmpty) return const SizedBox.shrink();
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      alignment: WrapAlignment.end,
      children: [for (final a in acts) _button(context, a)],
    );
  }

  Widget _button(BuildContext context, _A a) {
    final red = OutlinedButton.styleFrom(foregroundColor: Colors.red.shade700);
    switch (a) {
      case _A.approve:
        return FilledButton.icon(
            onPressed: () => SlipActions.approve(context, user, slip),
            icon: const Icon(Icons.check),
            label: const Text('Approve'));
      case _A.reject:
        return OutlinedButton.icon(
            style: red,
            onPressed: () => SlipActions.reject(context, user, slip),
            icon: const Icon(Icons.close),
            label: const Text('Reject'));
      case _A.edit:
        return OutlinedButton.icon(
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                builder: (_) =>
                    CreatePassSlipScreen(user: user, existing: slip))),
            icon: const Icon(Icons.edit_outlined),
            label: const Text('Edit'));
      case _A.cancel:
        return OutlinedButton.icon(
            style: red,
            onPressed: () => SlipActions.cancel(context, user, slip),
            icon: const Icon(Icons.block),
            label: const Text('Cancel'));
      case _A.delete:
        return OutlinedButton.icon(
            style: red,
            onPressed: () async {
              final ok = await SlipActions.delete(context, user, slip);
              if (ok) onDeleted?.call();
            },
            icon: const Icon(Icons.delete_outline),
            label: const Text('Delete'));
      case _A.timeOut:
        return FilledButton.icon(
            onPressed: () => SlipActions.timeOut(context, user, slip),
            icon: const Icon(Icons.logout),
            label: const Text('Verify & Time-Out'));
      case _A.timeIn:
        return FilledButton.icon(
            onPressed: () => SlipActions.timeIn(context, user, slip),
            icon: const Icon(Icons.login),
            label: const Text('Record Return'));
    }
  }
}
