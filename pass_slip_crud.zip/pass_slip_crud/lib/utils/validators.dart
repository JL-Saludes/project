import 'package:flutter/material.dart';
import 'formatters.dart';

class Validators {
  static String? required(String? v, String label) =>
      (v == null || v.trim().isEmpty) ? '$label is required.' : null;

  static String? dropdown(String? v, String label) =>
      (v == null || v.isEmpty) ? 'Please select $label.' : null;

  static String? email(String? v) {
    final r = required(v, 'Email');
    if (r != null) return r;
    final ok = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(v!.trim());
    return ok ? null : 'Enter a valid email address.';
  }

  static String? password(String? v) {
    if (v == null || v.isEmpty) return 'Password is required.';
    if (v.length < 6) return 'Password must be at least 6 characters.';
    return null;
  }

  static String? studentId(String? v) {
    final r = required(v, 'Student ID');
    if (r != null) return r;
    final ok = RegExp(r'^[A-Za-z0-9\-]{3,20}$').hasMatch(v!.trim());
    return ok
        ? null
        : 'Use letters, numbers and dashes only (3–20 characters).';
  }

  static String? personName(String? v) {
    final r = required(v, 'Student name');
    if (r != null) return r;
    final t = v!.trim();
    if (t.length < 3) return 'Enter the student\'s full name.';
    final ok = RegExp(r"^[\p{L} .'\-]+$", unicode: true).hasMatch(t);
    return ok ? null : 'Name contains invalid characters.';
  }

  static String? minLength(String? v, String label, [int n = 3]) {
    final r = required(v, label);
    if (r != null) return r;
    return v!.trim().length < n ? '$label is too short.' : null;
  }

  /// Authorized time-out must not be in the past (15-minute grace).
  static String? timeOut(DateTime? date, TimeOfDay? t) {
    if (date == null || t == null) return null;
    final out = combine(date, t);
    if (out.isBefore(DateTime.now().subtract(const Duration(minutes: 15)))) {
      return 'Time-out is already in the past.';
    }
    return null;
  }

  /// Expected return must be after the time-out and not already passed.
  static String? returnTime(DateTime? date, TimeOfDay? out, TimeOfDay? ret) {
    if (date == null || out == null || ret == null) return null;
    final outDt = combine(date, out);
    final retDt = combine(date, ret);
    if (!retDt.isAfter(outDt)) {
      return 'Return time must be later than the time-out.';
    }
    if (retDt.isBefore(DateTime.now())) {
      return 'Expected return time has already passed.';
    }
    return null;
  }
}
