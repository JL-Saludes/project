import 'package:flutter/material.dart';

class Collections {
  static const users = 'users';
  static const passSlips = 'pass_slips';
  static const activityLogs = 'activity_logs';
}

class Roles {
  static const faculty = 'FACULTY';
  static const personnel = 'AUTHORIZED_PERSONNEL';
  static const guard = 'GUARD';
  static const all = [faculty, personnel, guard];

  static String label(String role) {
    switch (role) {
      case faculty:
        return 'Faculty Member';
      case personnel:
        return 'Authorized Personnel';
      case guard:
        return 'Guard';
      default:
        return role;
    }
  }
}

class Status {
  static const pending = 'PENDING';
  static const approved = 'APPROVED';
  static const rejected = 'REJECTED';
  static const cancelled = 'CANCELLED';
  static const out = 'OUT';
  static const returned = 'RETURNED';

  /// Display-only status. It is computed (OUT + expected return passed) and
  /// is NEVER written to Firestore.
  static const overdue = 'OVERDUE';

  static const filterable = [
    pending, approved, rejected, cancelled, out, returned, overdue
  ];

  /// Slips that still "occupy" a student's time (used for overlap checks).
  static const active = [pending, approved, out];

  /// The only legal status transitions.
  static const transitions = <String, List<String>>{
    pending: [approved, rejected, cancelled],
    approved: [out, cancelled],
    out: [returned],
    rejected: [],
    cancelled: [],
    returned: [],
  };

  static String label(String s) =>
      s == out ? 'OUT' : s[0] + s.substring(1).toLowerCase();

  static Color color(String s) {
    switch (s) {
      case pending:
        return const Color(0xFFF59E0B);
      case approved:
        return const Color(0xFF16A34A);
      case rejected:
        return const Color(0xFFDC2626);
      case cancelled:
        return const Color(0xFF6B7280);
      case out:
        return const Color(0xFF2563EB);
      case returned:
        return const Color(0xFF0D9488);
      case overdue:
        return const Color(0xFFB91C1C);
      default:
        return Colors.grey;
    }
  }
}

class LogAction {
  static const created = 'CREATED';
  static const updated = 'UPDATED';
  static const approved = 'APPROVED';
  static const rejected = 'REJECTED';
  static const cancelled = 'CANCELLED';
  static const deleted = 'DELETED';
  static const timeOut = 'TIME_OUT';
  static const timeIn = 'TIME_IN';
}

class AppColors {
  static const primary = Color(0xFF1A4D8F);
  static const background = Color(0xFFF3F6FB);
}

class Lookups {
  // Edit these lists to match the school's actual offerings.
  static const programs = [
    'BS Information Technology',
    'BS Business Administration',
    'BS Education (Secondary)',
    'BS Elementary Education',
    'BS Hospitality Management',
    'BS Tourism Management',
    'BS Criminology',
    'BS Accountancy',
  ];
  static const yearLevels = [
    '1st Year', '2nd Year', '3rd Year', '4th Year', '5th Year'
  ];
}
