import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

final _dateFmt = DateFormat('MMM d, yyyy');
final _timeFmt = DateFormat('h:mm a');
final _dateTimeFmt = DateFormat('MMM d, yyyy h:mm a');

String fmtDate(DateTime? d) => d == null ? '—' : _dateFmt.format(d);
String fmtTime(DateTime? d) => d == null ? '—' : _timeFmt.format(d);
String fmtDateTime(DateTime? d) => d == null ? '—' : _dateTimeFmt.format(d);
String fmtTimeOfDay(TimeOfDay? t) {
  if (t == null) return '';
  return _timeFmt.format(DateTime(2000, 1, 1, t.hour, t.minute));
}

DateTime dayOnly(DateTime d) => DateTime(d.year, d.month, d.day);
bool isSameDay(DateTime a, DateTime b) =>
    a.year == b.year && a.month == b.month && a.day == b.day;
DateTime combine(DateTime date, TimeOfDay t) =>
    DateTime(date.year, date.month, date.day, t.hour, t.minute);
