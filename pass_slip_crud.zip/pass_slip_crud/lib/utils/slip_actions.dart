import 'package:flutter/material.dart';
import '../models/pass_slip_model.dart';
import '../models/user_model.dart';
import '../services/firestore_service.dart';
import 'app_exception.dart';
import 'formatters.dart';
import 'ui_helpers.dart';

/// UI-level wrappers: confirm -> call service -> SnackBar. Every method
/// returns true on success. Raw exceptions never reach the user.
class SlipActions {
  static final _svc = FirestoreService.instance;

  static Future<bool> _run(
      BuildContext c, Future<void> Function() task, String success) async {
    try {
      await task();
      if (c.mounted) showSnack(c, success);
      return true;
    } catch (e) {
      if (c.mounted) showSnack(c, friendlyError(e), error: true);
      return false;
    }
  }

  static Future<bool> approve(BuildContext c, UserModel u, PassSlipModel s) async {
    final ok = await confirmDialog(c,
        title: 'Approve pass slip?',
        message: 'Approve ${s.passSlipId} for ${s.studentName}?',
        confirmLabel: 'Approve');
    if (!ok || !c.mounted) return false;
    return _run(c, () => _svc.approve(u, s.passSlipId), 'Pass slip approved.');
  }

  static Future<bool> reject(BuildContext c, UserModel u, PassSlipModel s) async {
    final reason = await reasonDialog(c);
    if (reason == null || !c.mounted) return false;
    return _run(
        c, () => _svc.reject(u, s.passSlipId, reason), 'Pass slip rejected.');
  }

  static Future<bool> cancel(BuildContext c, UserModel u, PassSlipModel s) async {
    final ok = await confirmDialog(c,
        title: 'Cancel pass slip?',
        message:
            'Cancel ${s.passSlipId} for ${s.studentName}? This cannot be undone.',
        confirmLabel: 'Cancel slip',
        destructive: true);
    if (!ok || !c.mounted) return false;
    return _run(c, () => _svc.cancel(u, s.passSlipId), 'Pass slip cancelled.');
  }

  static Future<bool> delete(BuildContext c, UserModel u, PassSlipModel s) async {
    final ok = await confirmDialog(c,
        title: 'Delete permanently?',
        message:
            'Permanently delete ${s.passSlipId}? This record will be removed and cannot be recovered.',
        confirmLabel: 'Delete',
        destructive: true);
    if (!ok || !c.mounted) return false;
    return _run(
        c, () => _svc.deletePassSlip(u, s.passSlipId), 'Pass slip deleted.');
  }

  static Future<bool> timeOut(BuildContext c, UserModel u, PassSlipModel s) async {
    final ok = await confirmDialog(c,
        title: 'Confirm time-out',
        message:
            '${s.studentName} (${s.studentId}) is leaving for ${s.destination}.\n'
            'Expected return: ${fmtTime(s.expectedReturnTime)}.\n\n'
            'Record the time-out now?',
        confirmLabel: 'Record time-out');
    if (!ok || !c.mounted) return false;
    return _run(c, () => _svc.recordTimeOut(u, s.passSlipId),
        'Time-out recorded. Student is now OUT.');
  }

  static Future<bool> timeIn(BuildContext c, UserModel u, PassSlipModel s) async {
    final ok = await confirmDialog(c,
        title: 'Confirm return',
        message:
            'Record the return of ${s.studentName} (${s.studentId}) now?',
        confirmLabel: 'Record return');
    if (!ok || !c.mounted) return false;
    return _run(c, () => _svc.recordTimeIn(u, s.passSlipId),
        'Return recorded. Pass slip completed.');
  }
}
