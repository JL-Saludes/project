import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';

/// An error whose message is safe and friendly to show to the user.
class AppException implements Exception {
  final String message;
  const AppException(this.message);
  @override
  String toString() => message;
}

String authMessage(String code) {
  switch (code) {
    case 'invalid-credential':
    case 'wrong-password':
    case 'user-not-found':
    case 'invalid-login-credentials':
      return 'Incorrect email or password.';
    case 'invalid-email':
      return 'Please enter a valid email address.';
    case 'user-disabled':
      return 'This account has been disabled. Contact the administrator.';
    case 'too-many-requests':
      return 'Too many attempts. Please wait a moment and try again.';
    case 'network-request-failed':
      return 'No internet connection. Check your network and try again.';
    default:
      return 'Unable to sign in. Please try again.';
  }
}

String firestoreMessage(String code, String fallback) {
  switch (code) {
    case 'permission-denied':
      return 'You are not allowed to perform this action.';
    case 'unavailable':
    case 'deadline-exceeded':
    case 'network-request-failed':
      return 'Network problem. Check your connection and try again.';
    case 'not-found':
      return 'The record could not be found. It may have been removed.';
    case 'unauthenticated':
      return 'Your session has expired. Please sign in again.';
    default:
      return fallback;
  }
}

/// Converts ANY error into a clean message. Raw exceptions are never shown.
String friendlyError(Object error,
    {String fallback = 'Something went wrong. Please try again.'}) {
  if (error is AppException) return error.message;
  if (error is FirebaseAuthException) return authMessage(error.code);
  if (error is FirebaseException) return firestoreMessage(error.code, fallback);
  return fallback;
}
