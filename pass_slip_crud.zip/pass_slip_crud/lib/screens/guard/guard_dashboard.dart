import 'package:flutter/material.dart';
import '../../models/pass_slip_model.dart';
import '../../models/user_model.dart';
import '../../services/firestore_service.dart';
import '../../utils/app_exception.dart';
import '../../utils/constants.dart';
import '../../utils/formatters.dart';
import '../../widgets/dashboard_widgets.dart';
import '../../widgets/loading_widget.dart';
import '../profile/profile_screen.dart';
import 'guard_verification.dart';

class GuardDashboard extends StatefulWidget {
  final UserModel user;
  const GuardDashboard({super.key, required this.user});
  @override
  State<GuardDashboard> createState() => _GuardDashboardState();
}

class _GuardDashboardState extends State<GuardDashboard> {
  late final Stream<List<PassSlipModel>> _stream =
      FirestoreService.instance.guardSlips();

  void _go(Widget w) =>
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => w));

  void _verify(int tab, {bool search = false}) => _go(GuardVerificationScreen(
      user: widget.user, initialTab: tab, autofocusSearch: search));

  @override
  Widget build(BuildContext context) {
    final u = widget.user;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Guard Dashboard'),
        actions: [
          IconButton(
              tooltip: 'Profile',
              icon: const Icon(Icons.account_circle_outlined),
              onPressed: () => _go(ProfileScreen(user: u))),
        ],
      ),
      body: StreamBuilder<List<PassSlipModel>>(
        stream: _stream,
        builder: (context, snap) {
          if (snap.hasError) {
            return EmptyState(
                icon: Icons.error_outline,
                title: 'Unable to load dashboard',
                message: friendlyError(snap.error!));
          }
          if (!snap.hasData) return const LoadingWidget();
          final s = snap.data!;
          final now = DateTime.now();
          final approved = s.where((x) => x.status == Status.approved).toList();
          final awaiting =
              approved.where((x) => isSameDay(x.date, now)).length;
          final out = s.where((x) => x.status == Status.out).length;
          final retToday = s
              .where((x) =>
                  x.status == Status.returned &&
                  x.actualTimeIn != null &&
                  isSameDay(x.actualTimeIn!, now))
              .length;
          return Align(
            alignment: Alignment.topCenter,
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 1000),
              child: ListView(padding: const EdgeInsets.all(16), children: [
                WelcomeBanner(name: u.fullName, roleLabel: Roles.label(u.role)),
                const SectionTitle('Today at the Gate'),
                ResponsiveWrap(children: [
                  StatCard(
                      title: 'Approved Pass Slips',
                      value: approved.length,
                      icon: Icons.verified_outlined,
                      color: Status.color(Status.approved),
                      onTap: () => _verify(0)),
                  StatCard(
                      title: 'Currently OUT',
                      value: out,
                      icon: Icons.directions_walk,
                      color: Status.color(Status.out),
                      onTap: () => _verify(1)),
                  StatCard(
                      title: 'Returned Today',
                      value: retToday,
                      icon: Icons.assignment_turned_in_outlined,
                      color: Status.color(Status.returned),
                      onTap: () => _verify(2)),
                  StatCard(
                      title: 'Awaiting Verification (today)',
                      value: awaiting,
                      icon: Icons.pending_actions,
                      color: Status.color(Status.pending),
                      onTap: () => _verify(0)),
                ]),
                const SectionTitle('Quick Actions'),
                ResponsiveWrap(minItemWidth: 140, children: [
                  QuickActionTile(
                      label: 'Verify Pass Slip',
                      icon: Icons.fact_check_outlined,
                      onTap: () => _verify(0)),
                  QuickActionTile(
                      label: 'Currently Out',
                      icon: Icons.directions_walk,
                      onTap: () => _verify(1)),
                  QuickActionTile(
                      label: 'Return Student',
                      icon: Icons.login,
                      onTap: () => _verify(1)),
                  QuickActionTile(
                      label: 'Search Pass Slip',
                      icon: Icons.search,
                      onTap: () => _verify(0, search: true)),
                ]),
              ]),
            ),
          );
        },
      ),
    );
  }
}
