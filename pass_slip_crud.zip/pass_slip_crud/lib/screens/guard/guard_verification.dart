import 'package:flutter/material.dart';
import '../../models/pass_slip_model.dart';
import '../../models/user_model.dart';
import '../../services/firestore_service.dart';
import '../../utils/constants.dart';
import '../../widgets/slip_action_bar.dart';
import '../../widgets/slip_list_view.dart';
import '../pass_slip/pass_slip_details.dart';

/// Tabs: 0 Verify (APPROVED → OUT) • 1 Currently OUT (OUT → RETURNED) •
/// 2 Completed (RETURNED). Search covers slip ID, student ID and name.
class GuardVerificationScreen extends StatelessWidget {
  final UserModel user;
  final int initialTab;
  final bool autofocusSearch;
  const GuardVerificationScreen(
      {super.key,
      required this.user,
      this.initialTab = 0,
      this.autofocusSearch = false});

  void _open(BuildContext context, String id) =>
      Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => PassSlipDetailsScreen(user: user, passSlipId: id)));

  Widget? _actions(PassSlipModel s) =>
      SlipActionBar.hasActions(user, s) ? SlipActionBar(user: user, slip: s) : null;

  @override
  Widget build(BuildContext context) {
    final svc = FirestoreService.instance;
    return DefaultTabController(
      length: 3,
      initialIndex: initialTab,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Guard Verification'),
          bottom: const TabBar(
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            indicatorColor: Colors.white,
            tabs: [
              Tab(text: 'Verify'),
              Tab(text: 'Currently OUT'),
              Tab(text: 'Completed'),
            ],
          ),
        ),
        body: TabBarView(children: [
          SlipListView(
            streamFactory: () => svc.slipsByStatus(Status.approved),
            autofocus: autofocusSearch,
            // Earliest authorized time-out first.
            sort: (a, b) => a.authorizedTimeOut.compareTo(b.authorizedTimeOut),
            searchHint: 'Slip ID, Student ID or Student name',
            emptyTitle: 'No approved pass slips awaiting verification',
            onTap: (s) => _open(context, s.passSlipId),
            actionsBuilder: _actions,
          ),
          SlipListView(
            streamFactory: () => svc.slipsByStatus(Status.out),
            filters: const [Status.overdue],
            detailed: true,
            sort: (a, b) {
              if (a.isOverdue != b.isOverdue) return a.isOverdue ? -1 : 1;
              return a.expectedReturnTime.compareTo(b.expectedReturnTime);
            },
            searchHint: 'Slip ID, Student ID or Student name',
            emptyTitle: 'No students are currently outside',
            onTap: (s) => _open(context, s.passSlipId),
            actionsBuilder: _actions,
          ),
          SlipListView(
            streamFactory: () => svc.slipsByStatus(Status.returned),
            dateFilter: true,
            detailed: true,
            searchHint: 'Slip ID, Student ID or Student name',
            emptyTitle: 'No completed pass slips yet',
            onTap: (s) => _open(context, s.passSlipId),
          ),
        ]),
      ),
    );
  }
}
