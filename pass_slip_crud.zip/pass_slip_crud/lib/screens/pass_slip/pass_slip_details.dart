import 'package:flutter/material.dart';
import '../../models/pass_slip_model.dart';
import '../../models/user_model.dart';
import '../../services/firestore_service.dart';
import '../../utils/app_exception.dart';
import '../../utils/constants.dart';
import '../../utils/formatters.dart';
import '../../widgets/loading_widget.dart';
import '../../widgets/slip_action_bar.dart';
import '../../widgets/status_badge.dart';

class PassSlipDetailsScreen extends StatefulWidget {
  final UserModel user;
  final String passSlipId;
  const PassSlipDetailsScreen(
      {super.key, required this.user, required this.passSlipId});

  @override
  State<PassSlipDetailsScreen> createState() => _PassSlipDetailsScreenState();
}

class _PassSlipDetailsScreenState extends State<PassSlipDetailsScreen> {
  late final Stream<PassSlipModel?> _stream =
      FirestoreService.instance.slipStream(widget.passSlipId);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pass Slip Details')),
      body: StreamBuilder<PassSlipModel?>(
        stream: _stream,
        builder: (context, snap) {
          if (snap.hasError) {
            return EmptyState(
                icon: Icons.error_outline,
                title: 'Unable to load this pass slip',
                message: friendlyError(snap.error!));
          }
          if (snap.connectionState == ConnectionState.waiting) {
            return const LoadingWidget();
          }
          final s = snap.data;
          if (s == null) {
            return const EmptyState(
                icon: Icons.search_off,
                title: 'Pass slip not found',
                message: 'It may have been deleted.');
          }
          return Align(
            alignment: Alignment.topCenter,
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 700),
              child: ListView(padding: const EdgeInsets.all(16), children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(s.passSlipId,
                              style: Theme.of(context)
                                  .textTheme
                                  .titleMedium
                                  ?.copyWith(fontWeight: FontWeight.bold)),
                          const SizedBox(height: 8),
                          StatusBadge(status: s.status, overdue: s.isOverdue),
                          if (s.isOverdue) ...[
                            const SizedBox(height: 8),
                            Text(
                                'Expected back at ${fmtTime(s.expectedReturnTime)} — student has not returned.',
                                style: TextStyle(
                                    color: Status.color(Status.overdue),
                                    fontWeight: FontWeight.w600)),
                          ],
                        ]),
                  ),
                ),
                _Section('Student', [
                  _Row('Name', s.studentName),
                  _Row('Student ID', s.studentId),
                  _Row('Program', s.program),
                  _Row('Year level', s.yearLevel),
                ]),
                _Section('Pass Slip', [
                  _Row('Purpose', s.purpose),
                  _Row('Destination', s.destination),
                  _Row('Date', fmtDate(s.date)),
                  _Row('Authorized time-out', fmtTime(s.authorizedTimeOut)),
                  _Row('Expected return', fmtTime(s.expectedReturnTime)),
                  _Row('Remarks', s.remarks),
                ]),
                _Section('Timeline', [
                  _Row('Created by', '${s.createdByName} • ${fmtDateTime(s.createdAt)}'),
                  if (s.approvedByName != null)
                    _Row('Approved by',
                        '${s.approvedByName} • ${fmtDateTime(s.approvedAt)}'),
                  if (s.rejectedByName != null) ...[
                    _Row('Rejected by',
                        '${s.rejectedByName} • ${fmtDateTime(s.rejectedAt)}'),
                    _Row('Reason', s.rejectionReason ?? '—'),
                  ],
                  if (s.actualTimeOut != null) ...[
                    _Row('Actual time-out', fmtDateTime(s.actualTimeOut)),
                    _Row('Time-out verified by',
                        '${s.timeOutVerifiedByName ?? '—'} • ${fmtDateTime(s.timeOutVerifiedAt)}'),
                  ],
                  if (s.actualTimeIn != null) ...[
                    _Row('Actual time-in', fmtDateTime(s.actualTimeIn)),
                    _Row('Time-in verified by',
                        '${s.timeInVerifiedByName ?? '—'} • ${fmtDateTime(s.timeInVerifiedAt)}'),
                  ],
                  _Row('Last updated', fmtDateTime(s.updatedAt)),
                ]),
                const SizedBox(height: 12),
                SlipActionBar(
                  user: widget.user,
                  slip: s,
                  onDeleted: () {
                    if (mounted) Navigator.of(context).pop();
                  },
                ),
                const SizedBox(height: 24),
              ]),
            ),
          );
        },
      ),
    );
  }
}

class _Section extends StatelessWidget {
  final String title;
  final List<Widget> rows;
  const _Section(this.title, this.rows);

  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(top: 12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title,
                style: Theme.of(context)
                    .textTheme
                    .titleSmall
                    ?.copyWith(fontWeight: FontWeight.bold)),
            const Divider(),
            ...rows,
          ]),
        ),
      );
}

class _Row extends StatelessWidget {
  final String label;
  final String value;
  const _Row(this.label, this.value);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(
              width: 140,
              child: Text(label, style: TextStyle(color: Colors.grey.shade700))),
          Expanded(
              child: Text(value.isEmpty ? '—' : value,
                  style: const TextStyle(fontWeight: FontWeight.w500))),
        ]),
      );
}
