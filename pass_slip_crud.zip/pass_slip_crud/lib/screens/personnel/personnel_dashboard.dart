import 'package:flutter/material.dart';
import '../../models/pass_slip_model.dart';
import '../../models/user_model.dart';
import '../../services/firestore_service.dart';
import '../../utils/app_exception.dart';
import '../../utils/constants.dart';
import '../../widgets/dashboard_widgets.dart';
import '../../widgets/loading_widget.dart';
import '../profile/profile_screen.dart';
import 'approval_screen.dart';
import 'monitoring_screen.dart';

class PersonnelDashboard extends StatefulWidget {
  final UserModel user;
  const PersonnelDashboard({super.key, required this.user});
  @override
  State<PersonnelDashboard> createState() => _PersonnelDashboardState();
}

class _PersonnelDashboardState extends State<PersonnelDashboard> {
  late final Stream<List<PassSlipModel>> _stream =
      FirestoreService.instance.allSlips();

  void _go(Widget w) =>
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => w));

  void _manage(int tab, {bool search = false}) => _go(ApprovalScreen(
      user: widget.user, initialTab: tab, autofocusSearch: search));

  @override
  Widget build(BuildContext context) {
    final u = widget.user;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Management Dashboard'),
        actions: [
          IconButton(
              tooltip: 'Profile',
              icon: const Icon(Icons.account_circle_outlined),
              onPressed: () => _go(ProfileScreen(user: u))),
        ],
      ),
      body: StreamBuilder<List<PassSlipModel>>(
        stream: _stream,
        builder: (context, snap) {
          if (snap.hasError) {
            return EmptyState(
                icon: Icons.error_outline,
                title: 'Unable to load dashboard',
                message: friendlyError(snap.error!));
          }
          if (!snap.hasData) return const LoadingWidget();
          final s = snap.data!;
          int c(String st) => s.where((x) => x.status == st).length;
          final overdue = s.where((x) => x.isOverdue).length;
          final pending = c(Status.pending);
          return Align(
            alignment: Alignment.topCenter,
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 1000),
              child: ListView(padding: const EdgeInsets.all(16), children: [
                WelcomeBanner(name: u.fullName, roleLabel: Roles.label(u.role)),
                if (pending > 0 || overdue > 0) ...[
                  const SizedBox(height: 12),
                  Card(
                    color: Colors.amber.shade50,
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Row(children: [
                        const Icon(Icons.notifications_active_outlined),
                        const SizedBox(width: 10),
                        Expanded(
                            child: Text([
                          if (pending > 0) '$pending pending request(s) need review',
                          if (overdue > 0) '$overdue student(s) overdue'
                        ].join(' • '))),
                      ]),
                    ),
                  ),
                ],
                const SectionTitle('Overview'),
                ResponsiveWrap(children: [
                  StatCard(
                      title: 'Total Pass Slips',
                      value: s.length,
                      icon: Icons.assignment,
                      color: AppColors.primary,
                      onTap: () => _manage(1)),
                  StatCard(
                      title: 'Pending',
                      value: pending,
                      icon: Icons.hourglass_top,
                      color: Status.color(Status.pending),
                      onTap: () => _manage(0)),
                  StatCard(
                      title: 'Approved',
                      value: c(Status.approved),
                      icon: Icons.check_circle_outline,
                      color: Status.color(Status.approved),
                      onTap: () => _manage(1)),
                  StatCard(
                      title: 'Rejected',
                      value: c(Status.rejected),
                      icon: Icons.cancel_outlined,
                      color: Status.color(Status.rejected),
                      onTap: () => _manage(1)),
                  StatCard(
                      title: 'Currently OUT',
                      value: c(Status.out),
                      icon: Icons.directions_walk,
                      color: Status.color(Status.out),
                      onTap: () => _go(MonitoringScreen(user: u))),
                  StatCard(
                      title: 'Returned',
                      value: c(Status.returned),
                      icon: Icons.assignment_turned_in_outlined,
                      color: Status.color(Status.returned),
                      onTap: () => _manage(2)),
                  StatCard(
                      title: 'Overdue',
                      value: overdue,
                      icon: Icons.warning_amber_rounded,
                      color: Status.color(Status.overdue),
                      onTap: () => _go(MonitoringScreen(user: u))),
                ]),
                const SectionTitle('Quick Access'),
                ResponsiveWrap(minItemWidth: 140, children: [
                  QuickActionTile(
                      label: 'Pending Requests',
                      icon: Icons.pending_actions,
                      onTap: () => _manage(0)),
                  QuickActionTile(
                      label: 'All Pass Slips',
                      icon: Icons.list_alt,
                      onTap: () => _manage(1)),
                  QuickActionTile(
                      label: 'Monitoring',
                      icon: Icons.monitor_heart_outlined,
                      onTap: () => _go(MonitoringScreen(user: u))),
                  QuickActionTile(
                      label: 'Search',
                      icon: Icons.search,
                      onTap: () => _manage(1, search: true)),
                  QuickActionTile(
                      label: 'Reports / History',
                      icon: Icons.history,
                      onTap: () => _manage(2)),
                  QuickActionTile(
                      label: 'Activity Log',
                      icon: Icons.receipt_long_outlined,
                      onTap: () => _manage(3)),
                ]),
              ]),
            ),
          );
        },
      ),
    );
  }
}
