import 'package:flutter/material.dart';
import '../../models/activity_log_model.dart';
import '../../models/pass_slip_model.dart';
import '../../models/user_model.dart';
import '../../services/firestore_service.dart';
import '../../utils/app_exception.dart';
import '../../utils/constants.dart';
import '../../utils/formatters.dart';
import '../../widgets/loading_widget.dart';
import '../../widgets/slip_action_bar.dart';
import '../../widgets/slip_list_view.dart';
import '../pass_slip/pass_slip_details.dart';

/// Tabs: 0 Pending (approve/reject) • 1 All slips (search/filter/manage) •
/// 2 History (time-out/return records) • 3 Activity log.
class ApprovalScreen extends StatelessWidget {
  final UserModel user;
  final int initialTab;
  final bool autofocusSearch;
  const ApprovalScreen(
      {super.key,
      required this.user,
      this.initialTab = 0,
      this.autofocusSearch = false});

  void _open(BuildContext context, String id) =>
      Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => PassSlipDetailsScreen(user: user, passSlipId: id)));

  Widget? _actions(PassSlipModel s) =>
      SlipActionBar.hasActions(user, s) ? SlipActionBar(user: user, slip: s) : null;

  @override
  Widget build(BuildContext context) {
    final svc = FirestoreService.instance;
    return DefaultTabController(
      length: 4,
      initialIndex: initialTab,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Pass Slip Management'),
          bottom: const TabBar(
            isScrollable: true,
            tabAlignment: TabAlignment.start,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            indicatorColor: Colors.white,
            tabs: [
              Tab(text: 'Pending'),
              Tab(text: 'All Slips'),
              Tab(text: 'History'),
              Tab(text: 'Activity Log'),
            ],
          ),
        ),
        body: TabBarView(children: [
          SlipListView(
            streamFactory: () => svc.slipsByStatus(Status.pending),
            detailed: true,
            emptyTitle: 'No pending requests 🎉',
            onTap: (s) => _open(context, s.passSlipId),
            actionsBuilder: _actions,
          ),
          SlipListView(
            streamFactory: svc.allSlips,
            filters: Status.filterable,
            dateFilter: true,
            autofocus: autofocusSearch,
            searchHint: 'Search by slip ID, student ID, student or faculty',
            onTap: (s) => _open(context, s.passSlipId),
            actionsBuilder: _actions,
          ),
          SlipListView(
            // Every slip that has actually left campus: time-out & return records.
            streamFactory: () => svc
                .allSlips()
                .map((l) => l.where((s) => s.actualTimeOut != null).toList()),
            filters: const [Status.out, Status.returned, Status.overdue],
            dateFilter: true,
            detailed: true,
            emptyTitle: 'No time-out or return records yet',
            onTap: (s) => _open(context, s.passSlipId),
          ),
          const _ActivityLogTab(),
        ]),
      ),
    );
  }
}

class _ActivityLogTab extends StatefulWidget {
  const _ActivityLogTab();
  @override
  State<_ActivityLogTab> createState() => _ActivityLogTabState();
}

class _ActivityLogTabState extends State<_ActivityLogTab> {
  late final Stream<List<ActivityLogModel>> _stream =
      FirestoreService.instance.activityLogs();

  IconData _icon(String a) {
    switch (a) {
      case LogAction.created:
        return Icons.note_add_outlined;
      case LogAction.updated:
        return Icons.edit_outlined;
      case LogAction.approved:
        return Icons.check_circle_outline;
      case LogAction.rejected:
        return Icons.cancel_outlined;
      case LogAction.cancelled:
        return Icons.block;
      case LogAction.deleted:
        return Icons.delete_outline;
      case LogAction.timeOut:
        return Icons.logout;
      case LogAction.timeIn:
        return Icons.login;
      default:
        return Icons.info_outline;
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<ActivityLogModel>>(
      stream: _stream,
      builder: (context, snap) {
        if (snap.hasError) {
          return EmptyState(
              icon: Icons.error_outline,
              title: 'Unable to load the activity log',
              message: friendlyError(snap.error!));
        }
        if (!snap.hasData) return const LoadingWidget();
        final logs = snap.data!;
        if (logs.isEmpty) {
          return const EmptyState(
              icon: Icons.receipt_long_outlined, title: 'No activity yet');
        }
        return Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 900),
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: logs.length,
              itemBuilder: (_, i) {
                final l = logs[i];
                return Card(
                  child: ListTile(
                    leading: CircleAvatar(child: Icon(_icon(l.action))),
                    title: Text(l.description),
                    subtitle: Text(
                        '${l.performedByName} (${Roles.label(l.userRole)}) • ${fmtDateTime(l.timestamp)}'),
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }
}
