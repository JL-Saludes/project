import 'dart:async';
import 'package:flutter/material.dart';
import '../../models/user_model.dart';
import '../../services/firestore_service.dart';
import '../../utils/constants.dart';
import '../../widgets/slip_list_view.dart';
import '../pass_slip/pass_slip_details.dart';

/// Live view of every student currently OUT (status == OUT).
/// OVERDUE is a computed label only; the stored status is never changed.
class MonitoringScreen extends StatefulWidget {
  final UserModel user;
  const MonitoringScreen({super.key, required this.user});
  @override
  State<MonitoringScreen> createState() => _MonitoringScreenState();
}

class _MonitoringScreenState extends State<MonitoringScreen> {
  Timer? _ticker;

  @override
  void initState() {
    super.initState();
    // Re-evaluate "overdue" every 30s without needing a Firestore change.
    _ticker = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Monitoring — Currently OUT')),
      body: SlipListView(
        streamFactory: () => FirestoreService.instance.slipsByStatus(Status.out),
        filters: const [Status.overdue],
        detailed: true,
        searchHint: 'Search student, ID, faculty…',
        emptyTitle: 'No students are currently outside',
        // Overdue first, then earliest expected return.
        sort: (a, b) {
          if (a.isOverdue != b.isOverdue) return a.isOverdue ? -1 : 1;
          return a.expectedReturnTime.compareTo(b.expectedReturnTime);
        },
        headerBuilder: (all) {
          final overdue = all.where((s) => s.isOverdue).length;
          return Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: Row(children: [
              Chip(
                  avatar: Icon(Icons.directions_walk,
                      size: 18, color: Status.color(Status.out)),
                  label: Text('${all.length} OUT')),
              const SizedBox(width: 8),
              Chip(
                  avatar: Icon(Icons.warning_amber_rounded,
                      size: 18, color: Status.color(Status.overdue)),
                  label: Text('$overdue OVERDUE')),
            ]),
          );
        },
        onTap: (s) => Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => PassSlipDetailsScreen(
                user: widget.user, passSlipId: s.passSlipId))),
      ),
    );
  }
}
