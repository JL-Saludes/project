import 'package:flutter/material.dart';
import '../../models/user_model.dart';
import '../../services/auth_service.dart';
import '../../utils/app_exception.dart';
import '../../utils/constants.dart';
import '../../utils/formatters.dart';
import '../../utils/ui_helpers.dart';

class ProfileScreen extends StatelessWidget {
  final UserModel user;
  const ProfileScreen({super.key, required this.user});

  Future<void> _logout(BuildContext context) async {
    final ok = await confirmDialog(context,
        title: 'Sign out?',
        message: 'You will need to sign in again to continue.',
        confirmLabel: 'Sign out');
    if (!ok || !context.mounted) return;
    final nav = Navigator.of(context);
    try {
      await AuthService.instance.signOut();
      // Remove every pushed screen so none of them stays on top of the login.
      nav.popUntil((r) => r.isFirst);
    } catch (e) {
      if (context.mounted) showSnack(context, friendlyError(e), error: true);
    }
  }

  Future<void> _reset(BuildContext context) async {
    try {
      await AuthService.instance.sendPasswordReset(user.email);
      if (context.mounted) {
        showSnack(context, 'Password reset email sent to ${user.email}.');
      }
    } catch (e) {
      if (context.mounted) showSnack(context, friendlyError(e), error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profile & Settings')),
      body: Align(
        alignment: Alignment.topCenter,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 600),
          child: ListView(padding: const EdgeInsets.all(16), children: [
            Center(
              child: Column(children: [
                CircleAvatar(
                    radius: 42,
                    backgroundColor: Theme.of(context).colorScheme.primary,
                    child: const Icon(Icons.person, size: 46, color: Colors.white)),
                const SizedBox(height: 12),
                Text(user.fullName,
                    style: Theme.of(context)
                        .textTheme
                        .titleLarge
                        ?.copyWith(fontWeight: FontWeight.bold)),
                Chip(label: Text(Roles.label(user.role))),
              ]),
            ),
            const SizedBox(height: 8),
            Card(
              child: Column(children: [
                ListTile(
                    leading: const Icon(Icons.email_outlined),
                    title: const Text('Email'),
                    subtitle: Text(user.email)),
                if (user.facultyId.isNotEmpty)
                  ListTile(
                      leading: const Icon(Icons.badge_outlined),
                      title: const Text('Faculty ID'),
                      subtitle: Text(user.facultyId)),
                ListTile(
                    leading: const Icon(Icons.event_available_outlined),
                    title: const Text('Account created'),
                    subtitle: Text(fmtDate(user.createdAt))),
              ]),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
                onPressed: () => _reset(context),
                icon: const Icon(Icons.lock_reset),
                label: const Text('Send password reset email')),
            const SizedBox(height: 12),
            FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: Colors.red.shade700),
                onPressed: () => _logout(context),
                icon: const Icon(Icons.logout),
                label: const Text('Sign out')),
          ]),
        ),
      ),
    );
  }
}
