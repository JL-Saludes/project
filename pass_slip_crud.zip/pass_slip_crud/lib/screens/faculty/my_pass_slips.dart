import 'package:flutter/material.dart';
import '../../models/user_model.dart';
import '../../services/firestore_service.dart';
import '../../utils/constants.dart';
import '../../widgets/slip_action_bar.dart';
import '../../widgets/slip_list_view.dart';
import '../pass_slip/pass_slip_details.dart';
import 'create_pass_slip.dart';

class MyPassSlipsScreen extends StatelessWidget {
  final UserModel user;
  final bool autofocusSearch;
  const MyPassSlipsScreen(
      {super.key, required this.user, this.autofocusSearch = false});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Pass Slips')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => CreatePassSlipScreen(user: user))),
        icon: const Icon(Icons.add),
        label: const Text('New'),
      ),
      // Faculty only ever query their own records (also enforced by rules).
      body: SlipListView(
        streamFactory: () => FirestoreService.instance.facultySlips(user.uid),
        filters: Status.filterable,
        dateFilter: true,
        showFaculty: false,
        autofocus: autofocusSearch,
        searchHint: 'Search my slips by ID, student ID or name',
        emptyTitle: 'You have not created any pass slips yet',
        onTap: (s) => Navigator.of(context).push(MaterialPageRoute(
            builder: (_) =>
                PassSlipDetailsScreen(user: user, passSlipId: s.passSlipId))),
        actionsBuilder: (s) =>
            SlipActionBar.hasActions(user, s) ? SlipActionBar(user: user, slip: s) : null,
      ),
    );
  }
}
