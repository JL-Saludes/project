import 'package:flutter/material.dart';
import '../../models/pass_slip_model.dart';
import '../../models/user_model.dart';
import '../../services/firestore_service.dart';
import '../../utils/app_exception.dart';
import '../../utils/constants.dart';
import '../../utils/formatters.dart';
import '../../utils/ui_helpers.dart';
import '../../utils/validators.dart';
import '../../widgets/custom_text_field.dart';

/// Create a new slip (faculty) or edit an existing one (faculty/personnel).
class CreatePassSlipScreen extends StatefulWidget {
  final UserModel user;
  final PassSlipModel? existing;
  const CreatePassSlipScreen({super.key, required this.user, this.existing});

  @override
  State<CreatePassSlipScreen> createState() => _CreatePassSlipScreenState();
}

class _CreatePassSlipScreenState extends State<CreatePassSlipScreen> {
  final _formKey = GlobalKey<FormState>();
  final _studentId = TextEditingController();
  final _studentName = TextEditingController();
  final _purpose = TextEditingController();
  final _destination = TextEditingController();
  final _remarks = TextEditingController();
  final _dateCtl = TextEditingController();
  final _outCtl = TextEditingController();
  final _retCtl = TextEditingController();

  String? _program;
  String? _year;
  DateTime? _date;
  TimeOfDay? _out;
  TimeOfDay? _ret;
  bool _saving = false;

  bool get _editing => widget.existing != null;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    if (e != null) {
      _studentId.text = e.studentId;
      _studentName.text = e.studentName;
      _purpose.text = e.purpose;
      _destination.text = e.destination;
      _remarks.text = e.remarks;
      _program = e.program;
      _year = e.yearLevel;
      _date = e.date;
      _out = TimeOfDay.fromDateTime(e.authorizedTimeOut);
      _ret = TimeOfDay.fromDateTime(e.expectedReturnTime);
      _dateCtl.text = fmtDate(_date);
      _outCtl.text = fmtTimeOfDay(_out);
      _retCtl.text = fmtTimeOfDay(_ret);
    }
  }

  @override
  void dispose() {
    for (final c in [
      _studentId, _studentName, _purpose, _destination, _remarks,
      _dateCtl, _outCtl, _retCtl
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _pickDate() async {
    final today = dayOnly(DateTime.now());
    final initial = (_date != null && !_date!.isBefore(today)) ? _date! : today;
    final d = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: today,
      lastDate: today.add(const Duration(days: 365)),
    );
    if (d != null) {
      setState(() {
        _date = d;
        _dateCtl.text = fmtDate(d);
      });
    }
  }

  Future<void> _pickTime({required bool isOut}) async {
    final t = await showTimePicker(
      context: context,
      initialTime: (isOut ? _out : _ret) ?? TimeOfDay.now(),
    );
    if (t != null) {
      setState(() {
        if (isOut) {
          _out = t;
          _outCtl.text = fmtTimeOfDay(t);
        } else {
          _ret = t;
          _retCtl.text = fmtTimeOfDay(t);
        }
      });
    }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) {
      showSnack(context, 'Please fix the highlighted fields.', error: true);
      return;
    }
    setState(() => _saving = true);
    final form = PassSlipForm(
      studentId: _studentId.text,
      studentName: _studentName.text,
      program: _program!,
      yearLevel: _year!,
      purpose: _purpose.text,
      destination: _destination.text,
      date: _date!,
      authorizedTimeOut: combine(_date!, _out!),
      expectedReturnTime: combine(_date!, _ret!),
      remarks: _remarks.text,
    );
    final nav = Navigator.of(context);
    final messenger = ScaffoldMessenger.of(context);
    try {
      final svc = FirestoreService.instance;
      String msg;
      if (_editing) {
        await svc.updatePassSlip(widget.user, widget.existing!, form);
        msg = 'Pass slip updated.';
      } else {
        final id = await svc.createPassSlip(widget.user, form);
        msg = 'Pass slip $id created and sent for approval.';
      }
      nav.pop();
      messenger
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(
            content: Text(msg),
            backgroundColor: Colors.green.shade700,
            behavior: SnackBarBehavior.floating));
    } catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        showSnack(context, friendlyError(e), error: true);
      }
    }
  }

  Widget _dropdown(String label, IconData icon, List<String> items,
      String? value, ValueChanged<String?> onChanged) {
    final opts = [...items, if (value != null && !items.contains(value)) value];
    return DropdownButtonFormField<String>(
      value: value,
      isExpanded: true,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
      ),
      items: [
        for (final o in opts) DropdownMenuItem(value: o, child: Text(o))
      ],
      validator: (v) => Validators.dropdown(v, label.toLowerCase()),
      onChanged: _saving ? null : onChanged,
      autovalidateMode: AutovalidateMode.onUserInteraction,
    );
  }

  @override
  Widget build(BuildContext context) {
    const gap = SizedBox(height: 16);
    return Scaffold(
      appBar: AppBar(title: Text(_editing ? 'Edit Pass Slip' : 'Create Pass Slip')),
      body: Align(
        alignment: Alignment.topCenter,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 700),
          child: Form(
            key: _formKey,
            child: ListView(padding: const EdgeInsets.all(16), children: [
              Card(
                color: Colors.blue.shade50,
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(children: [
                    const Icon(Icons.info_outline),
                    const SizedBox(width: 10),
                    Expanded(
                        child: Text(_editing
                            ? 'Editing ${widget.existing!.passSlipId}'
                            : 'The student does not need an account. Pass slip ID, status (PENDING) and your name are added automatically.')),
                  ]),
                ),
              ),
              gap,
              CustomTextField(
                controller: _studentId,
                label: 'Student ID',
                icon: Icons.badge_outlined,
                textCapitalization: TextCapitalization.characters,
                textInputAction: TextInputAction.next,
                validator: Validators.studentId,
                enabled: !_saving,
              ),
              gap,
              CustomTextField(
                controller: _studentName,
                label: 'Student Name',
                icon: Icons.person_outline,
                textCapitalization: TextCapitalization.words,
                textInputAction: TextInputAction.next,
                validator: Validators.personName,
                enabled: !_saving,
              ),
              gap,
              _dropdown('Program/Course', Icons.school_outlined, Lookups.programs,
                  _program, (v) => setState(() => _program = v)),
              gap,
              _dropdown('Year Level', Icons.stairs_outlined, Lookups.yearLevels,
                  _year, (v) => setState(() => _year = v)),
              gap,
              CustomTextField(
                controller: _purpose,
                label: 'Purpose',
                icon: Icons.edit_note,
                maxLines: 2,
                textCapitalization: TextCapitalization.sentences,
                validator: (v) => Validators.minLength(v, 'Purpose'),
                enabled: !_saving,
              ),
              gap,
              CustomTextField(
                controller: _destination,
                label: 'Destination',
                icon: Icons.place_outlined,
                textCapitalization: TextCapitalization.words,
                validator: (v) => Validators.minLength(v, 'Destination'),
                enabled: !_saving,
              ),
              gap,
              CustomTextField(
                controller: _dateCtl,
                label: 'Date',
                icon: Icons.event,
                readOnly: true,
                onTap: _saving ? null : _pickDate,
                validator: (v) => Validators.required(v, 'Date'),
              ),
              gap,
              Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Expanded(
                  child: CustomTextField(
                    controller: _outCtl,
                    label: 'Authorized Time-Out',
                    icon: Icons.logout,
                    readOnly: true,
                    onTap: _saving ? null : () => _pickTime(isOut: true),
                    validator: (v) =>
                        Validators.required(v, 'Time-out') ??
                        Validators.timeOut(_date, _out),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: CustomTextField(
                    controller: _retCtl,
                    label: 'Expected Return',
                    icon: Icons.login,
                    readOnly: true,
                    onTap: _saving ? null : () => _pickTime(isOut: false),
                    validator: (v) =>
                        Validators.required(v, 'Return time') ??
                        Validators.returnTime(_date, _out, _ret),
                  ),
                ),
              ]),
              gap,
              CustomTextField(
                controller: _remarks,
                label: 'Remarks (optional)',
                icon: Icons.notes,
                maxLines: 3,
                textCapitalization: TextCapitalization.sentences,
                enabled: !_saving,
              ),
              const SizedBox(height: 24),
              SizedBox(
                height: 50,
                child: FilledButton.icon(
                  onPressed: _saving ? null : _submit,
                  icon: _saving
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                              strokeWidth: 2.5, color: Colors.white))
                      : Icon(_editing ? Icons.save : Icons.send),
                  label: Text(_editing ? 'Save Changes' : 'Submit Pass Slip'),
                ),
              ),
              const SizedBox(height: 24),
            ]),
          ),
        ),
      ),
    );
  }
}
