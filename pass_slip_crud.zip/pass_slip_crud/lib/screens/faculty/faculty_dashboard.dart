import 'package:flutter/material.dart';
import '../../models/pass_slip_model.dart';
import '../../models/user_model.dart';
import '../../services/firestore_service.dart';
import '../../utils/app_exception.dart';
import '../../utils/constants.dart';
import '../../widgets/dashboard_widgets.dart';
import '../../widgets/loading_widget.dart';
import '../../widgets/pass_slip_card.dart';
import '../pass_slip/pass_slip_details.dart';
import '../profile/profile_screen.dart';
import 'create_pass_slip.dart';
import 'my_pass_slips.dart';

class FacultyDashboard extends StatefulWidget {
  final UserModel user;
  const FacultyDashboard({super.key, required this.user});
  @override
  State<FacultyDashboard> createState() => _FacultyDashboardState();
}

class _FacultyDashboardState extends State<FacultyDashboard> {
  late final Stream<List<PassSlipModel>> _stream =
      FirestoreService.instance.facultySlips(widget.user.uid);

  void _go(Widget w) =>
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => w));

  @override
  Widget build(BuildContext context) {
    final u = widget.user;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Faculty Dashboard'),
        actions: [
          IconButton(
              tooltip: 'Profile',
              icon: const Icon(Icons.account_circle_outlined),
              onPressed: () => _go(ProfileScreen(user: u))),
        ],
      ),
      body: StreamBuilder<List<PassSlipModel>>(
        stream: _stream,
        builder: (context, snap) {
          if (snap.hasError) {
            return EmptyState(
                icon: Icons.error_outline,
                title: 'Unable to load dashboard',
                message: friendlyError(snap.error!));
          }
          if (!snap.hasData) return const LoadingWidget();
          final s = snap.data!;
          int c(String st) => s.where((x) => x.status == st).length;
          return Align(
            alignment: Alignment.topCenter,
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 1000),
              child: ListView(padding: const EdgeInsets.all(16), children: [
                WelcomeBanner(
                    name: u.fullName, roleLabel: Roles.label(u.role)),
                const SectionTitle('My Pass Slips'),
                ResponsiveWrap(children: [
                  StatCard(
                      title: 'Total Created',
                      value: s.length,
                      icon: Icons.assignment,
                      color: AppColors.primary,
                      onTap: () => _go(MyPassSlipsScreen(user: u))),
                  StatCard(
                      title: 'Pending',
                      value: c(Status.pending),
                      icon: Icons.hourglass_top,
                      color: Status.color(Status.pending)),
                  StatCard(
                      title: 'Approved',
                      value: c(Status.approved),
                      icon: Icons.check_circle_outline,
                      color: Status.color(Status.approved)),
                  StatCard(
                      title: 'Rejected',
                      value: c(Status.rejected),
                      icon: Icons.cancel_outlined,
                      color: Status.color(Status.rejected)),
                  StatCard(
                      title: 'Returned',
                      value: c(Status.returned),
                      icon: Icons.assignment_turned_in_outlined,
                      color: Status.color(Status.returned)),
                ]),
                const SectionTitle('Quick Actions'),
                ResponsiveWrap(minItemWidth: 140, children: [
                  QuickActionTile(
                      label: 'Create Pass Slip',
                      icon: Icons.note_add_outlined,
                      onTap: () => _go(CreatePassSlipScreen(user: u))),
                  QuickActionTile(
                      label: 'My Pass Slips',
                      icon: Icons.list_alt,
                      onTap: () => _go(MyPassSlipsScreen(user: u))),
                  QuickActionTile(
                      label: 'Search',
                      icon: Icons.search,
                      onTap: () =>
                          _go(MyPassSlipsScreen(user: u, autofocusSearch: true))),
                  QuickActionTile(
                      label: 'Profile',
                      icon: Icons.person_outline,
                      onTap: () => _go(ProfileScreen(user: u))),
                ]),
                const SectionTitle('Recent Activity'),
                if (s.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 24),
                    child: EmptyState(
                        icon: Icons.assignment_outlined,
                        title: 'No pass slips yet',
                        message: 'Tap "Create Pass Slip" to issue your first one.'),
                  )
                else
                  for (final slip in s.take(5))
                    PassSlipCard(
                      slip: slip,
                      showFaculty: false,
                      onTap: () => _go(
                          PassSlipDetailsScreen(user: u, passSlipId: slip.passSlipId)),
                    ),
              ]),
            ),
          );
        },
      ),
    );
  }
}
