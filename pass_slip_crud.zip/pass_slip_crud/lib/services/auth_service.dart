import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../utils/app_exception.dart';
import 'firestore_service.dart';


class AuthService {
  AuthService._();
  static final AuthService instance = AuthService._();

  final FirebaseAuth _auth = FirebaseAuth.instance;

  Stream<User?> get authChanges => _auth.authStateChanges();
  User? get currentUser => _auth.currentUser;

  /// Signs in, then verifies a valid role exists in Firestore. Users with no
  /// profile / role are signed out immediately.
  Future<void> signIn(String email, String password) async {
    try {
      final cred = await _auth.signInWithEmailAndPassword(
          email: email.trim(), password: password);
      final profile = await FirestoreService.instance.getUser(cred.user!.uid);
      if (profile == null || !profile.hasValidRole) {
        await _auth.signOut();
        throw const AppException(
            'Your account has no assigned role. Contact the administrator.');
      }
    } on AppException {
      rethrow;
    } on FirebaseAuthException catch (e) {
      debugPrint('LOGIN AUTH ERROR: code=${e.code} message=${e.message}');
      throw AppException(authMessage(e.code));
    } catch (e) {
      debugPrint('LOGIN OTHER ERROR: $e');
      await _auth.signOut();
      throw AppException(friendlyError(e,
          fallback: 'Unable to sign in. Please try again.'));
    }
  }

  Future<void> signOut() => _auth.signOut();

  Future<void> sendPasswordReset(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
    } catch (e) {
      throw AppException(friendlyError(e,
          fallback: 'Unable to send the reset email. Please try again.'));
    }
  }
}
