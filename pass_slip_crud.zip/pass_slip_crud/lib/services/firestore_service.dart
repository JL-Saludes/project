import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/activity_log_model.dart';
import '../models/pass_slip_model.dart';
import '../models/user_model.dart';
import '../utils/app_exception.dart';
import '../utils/constants.dart';
import '../utils/formatters.dart';

typedef Json = Map<String, dynamic>;

class FirestoreService {
  FirestoreService._();
  static final FirestoreService instance = FirestoreService._();

  final FirebaseFirestore _db = FirebaseFirestore.instance;

  CollectionReference<Json> get _users => _db.collection(Collections.users);
  CollectionReference<Json> get _slips => _db.collection(Collections.passSlips);
  CollectionReference<Json> get _logs =>
      _db.collection(Collections.activityLogs);

  static const _denied =
      AppException('You are not allowed to perform this action.');

  // ------------------------------------------------------------------ users
  Future<UserModel?> getUser(String uid) async {
    final doc = await _users.doc(uid).get();
    return doc.exists ? UserModel.fromDoc(doc) : null;
  }

  Stream<UserModel?> userStream(String uid) => _users
      .doc(uid)
      .snapshots()
      .map((d) => d.exists ? UserModel.fromDoc(d) : null);

  // ----------------------------------------------------------------- streams
  // No orderBy + where combos => no composite indexes needed. Sorting is
  // done on the client.
  Stream<List<PassSlipModel>> _stream(Query<Json> q) => q.snapshots().map((s) {
        final list = s.docs.map((d) => PassSlipModel.fromMap(d.data())).toList();
        final now = DateTime.now();
        list.sort((a, b) =>
            (b.createdAt ?? now).compareTo(a.createdAt ?? now));
        return list;
      });

  Stream<List<PassSlipModel>> facultySlips(String uid) =>
      _stream(_slips.where('createdBy', isEqualTo: uid));

  /// Personnel only.
  Stream<List<PassSlipModel>> allSlips() => _stream(_slips);

  Stream<List<PassSlipModel>> slipsByStatus(String status) =>
      _stream(_slips.where('status', isEqualTo: status));

  /// Guard-visible records (APPROVED, OUT, RETURNED).
  Stream<List<PassSlipModel>> guardSlips() => _stream(_slips.where('status',
      whereIn: [Status.approved, Status.out, Status.returned]));

  Stream<PassSlipModel?> slipStream(String id) => _slips
      .doc(id)
      .snapshots()
      .map((d) => d.exists ? PassSlipModel.fromMap(d.data()!) : null);

  Stream<List<ActivityLogModel>> activityLogs({int limit = 200}) => _logs
      .orderBy('timestamp', descending: true)
      .limit(limit)
      .snapshots()
      .map((s) => s.docs.map(ActivityLogModel.fromDoc).toList());

  // ----------------------------------------------------------------- helpers
  Future<T> _run<T>(Future<T> Function() task, String fallback) async {
    try {
      return await task();
    } on AppException {
      rethrow;
    } on FirebaseException catch (e) {
      throw AppException(firestoreMessage(e.code, fallback));
    } catch (_) {
      throw AppException(fallback);
    }
  }

  Json _log(UserModel actor, String action, String slipId, String desc) => {
        'action': action,
        'passSlipId': slipId,
        'performedBy': actor.uid,
        'performedByName': actor.fullName,
        'userRole': actor.role,
        'timestamp': FieldValue.serverTimestamp(),
        'description': desc,
      };

  void _require(UserModel actor, String role) {
    if (actor.role != role) throw _denied;
  }

  void _assertTransition(String from, String to) {
    final ok = Status.transitions[from]?.contains(to) ?? false;
    if (!ok) {
      throw AppException(
          'Invalid action: a ${Status.label(from)} pass slip cannot become ${Status.label(to)}.');
    }
  }

  String _generateId() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final r = Random.secure();
    final code = List.generate(6, (_) => chars[r.nextInt(chars.length)]).join();
    final d = DateTime.now();
    final ymd =
        '${d.year}${d.month.toString().padLeft(2, '0')}${d.day.toString().padLeft(2, '0')}';
    return 'PS-$ymd-$code';
  }

  /// Rejects a submission if the same student already has an active slip by
  /// this faculty member whose time window overlaps.
  Future<void> _assertNoOverlap(String facultyUid, PassSlipForm f,
      {String? excludeId}) async {
    final q = await _slips
        .where('createdBy', isEqualTo: facultyUid)
        .where('studentId', isEqualTo: f.studentId)
        .get();
    for (final doc in q.docs) {
      final s = PassSlipModel.fromMap(doc.data());
      if (s.passSlipId == excludeId) continue;
      if (!Status.active.contains(s.status)) continue;
      final overlaps = s.authorizedTimeOut.isBefore(f.expectedReturnTime) &&
          f.authorizedTimeOut.isBefore(s.expectedReturnTime);
      if (overlaps) {
        throw AppException(
            'This student already has an active pass slip (${s.passSlipId}) that overlaps this time.');
      }
    }
  }

  // ------------------------------------------------------------------ CREATE
  Future<String> createPassSlip(UserModel actor, PassSlipForm form) => _run(() async {
        _require(actor, Roles.faculty);
        await _assertNoOverlap(actor.uid, form);
        final id = _generateId();
        final batch = _db.batch();
        batch.set(_slips.doc(id), {
          'passSlipId': id,
          ...form.toMap(),
          'actualTimeOut': null,
          'actualTimeIn': null,
          'status': Status.pending,
          'createdBy': actor.uid,
          'createdByName': actor.fullName,
          'createdAt': FieldValue.serverTimestamp(),
          'approvedBy': null,
          'approvedByName': null,
          'approvedAt': null,
          'rejectedBy': null,
          'rejectedByName': null,
          'rejectedAt': null,
          'rejectionReason': null,
          'timeOutVerifiedBy': null,
          'timeOutVerifiedByName': null,
          'timeOutVerifiedAt': null,
          'timeInVerifiedBy': null,
          'timeInVerifiedByName': null,
          'timeInVerifiedAt': null,
          'updatedAt': FieldValue.serverTimestamp(),
        });
        batch.set(
            _logs.doc(),
            _log(actor, LogAction.created, id,
                'Created pass slip $id for ${form.studentName.trim()} (${form.studentId}).'));
        await batch.commit();
        return id;
      }, 'Unable to save the pass slip. Please try again.');

  // ------------------------------------------------------------------ UPDATE
  Future<void> updatePassSlip(
          UserModel actor, PassSlipModel slip, PassSlipForm form) =>
      _run(() async {
        if (actor.role == Roles.guard) throw _denied;
        if (actor.role == Roles.faculty) {
          await _assertNoOverlap(actor.uid, form, excludeId: slip.passSlipId);
        }
        final ref = _slips.doc(slip.passSlipId);
        await _db.runTransaction((tx) async {
          final snap = await tx.get(ref);
          if (!snap.exists) {
            throw const AppException('This pass slip no longer exists.');
          }
          final cur = PassSlipModel.fromMap(snap.data()!);
          if (actor.role == Roles.faculty && cur.createdBy != actor.uid) {
            throw _denied;
          }
          final editable = actor.role == Roles.faculty
              ? [Status.pending]
              : [Status.pending, Status.approved];
          if (!editable.contains(cur.status)) {
            throw AppException(
                'This pass slip can no longer be edited because it is ${Status.label(cur.status)}.');
          }
          tx.update(ref, {
            ...form.toMap(),
            'updatedAt': FieldValue.serverTimestamp(),
          });
          tx.set(
              _logs.doc(),
              _log(actor, LogAction.updated, cur.passSlipId,
                  'Updated pass slip ${cur.passSlipId}.'));
        });
      }, 'Unable to update the pass slip. Please try again.');

  /// Shared engine for every status change. Re-reads the slip inside a
  /// transaction and validates the transition before writing.
  Future<void> _transition({
    required UserModel actor,
    required String id,
    required String to,
    required String action,
    required String Function(PassSlipModel s) describe,
    required String failure,
    Json extra = const {},
    void Function(PassSlipModel s)? check,
  }) =>
      _run(() async {
        final ref = _slips.doc(id);
        await _db.runTransaction((tx) async {
          final snap = await tx.get(ref);
          if (!snap.exists) {
            throw const AppException('This pass slip no longer exists.');
          }
          final slip = PassSlipModel.fromMap(snap.data()!);
          _assertTransition(slip.status, to);
          check?.call(slip);
          tx.update(ref, {
            'status': to,
            ...extra,
            'updatedAt': FieldValue.serverTimestamp(),
          });
          tx.set(_logs.doc(), _log(actor, action, id, describe(slip)));
        });
      }, failure);

  Future<void> approve(UserModel actor, String id) {
    _require(actor, Roles.personnel);
    return _transition(
      actor: actor,
      id: id,
      to: Status.approved,
      action: LogAction.approved,
      describe: (s) => 'Approved pass slip $id for ${s.studentName}.',
      failure: 'Unable to approve the pass slip. Please try again.',
      extra: {
        'approvedBy': actor.uid,
        'approvedByName': actor.fullName,
        'approvedAt': FieldValue.serverTimestamp(),
      },
    );
  }

  Future<void> reject(UserModel actor, String id, String reason) {
    _require(actor, Roles.personnel);
    if (reason.trim().isEmpty) {
      throw const AppException('A rejection reason is required.');
    }
    return _transition(
      actor: actor,
      id: id,
      to: Status.rejected,
      action: LogAction.rejected,
      describe: (s) =>
          'Rejected pass slip $id for ${s.studentName}. Reason: ${reason.trim()}',
      failure: 'Unable to reject the pass slip. Please try again.',
      extra: {
        'rejectedBy': actor.uid,
        'rejectedByName': actor.fullName,
        'rejectedAt': FieldValue.serverTimestamp(),
        'rejectionReason': reason.trim(),
      },
    );
  }

  Future<void> cancel(UserModel actor, String id) {
    if (actor.role == Roles.guard) throw _denied;
    return _transition(
      actor: actor,
      id: id,
      to: Status.cancelled,
      action: LogAction.cancelled,
      describe: (s) => 'Cancelled pass slip $id for ${s.studentName}.',
      failure: 'Unable to cancel the pass slip. Please try again.',
      check: (s) {
        if (actor.role == Roles.faculty && s.createdBy != actor.uid) {
          throw const AppException('You can only cancel your own pass slips.');
        }
      },
    );
  }

  /// Guard: APPROVED -> OUT.
  Future<void> recordTimeOut(UserModel actor, String id) {
    _require(actor, Roles.guard);
    return _transition(
      actor: actor,
      id: id,
      to: Status.out,
      action: LogAction.timeOut,
      describe: (s) =>
          'Verified time-out of ${s.studentName} (${s.studentId}) on pass slip $id.',
      failure: 'Unable to record the time-out. Please try again.',
      check: (s) {
        if (!isSameDay(s.date, DateTime.now())) {
          throw AppException(
              'This pass slip is dated ${fmtDate(s.date)}, not today. The student cannot leave yet.');
        }
      },
      extra: {
        'actualTimeOut': FieldValue.serverTimestamp(),
        'timeOutVerifiedBy': actor.uid,
        'timeOutVerifiedByName': actor.fullName,
        'timeOutVerifiedAt': FieldValue.serverTimestamp(),
      },
    );
  }

  /// Guard: OUT -> RETURNED.
  Future<void> recordTimeIn(UserModel actor, String id) {
    _require(actor, Roles.guard);
    return _transition(
      actor: actor,
      id: id,
      to: Status.returned,
      action: LogAction.timeIn,
      describe: (s) =>
          'Recorded return of ${s.studentName} (${s.studentId}) on pass slip $id.',
      failure: 'Unable to record the return. Please try again.',
      extra: {
        'actualTimeIn': FieldValue.serverTimestamp(),
        'timeInVerifiedBy': actor.uid,
        'timeInVerifiedByName': actor.fullName,
        'timeInVerifiedAt': FieldValue.serverTimestamp(),
      },
    );
  }

  // ------------------------------------------------------------------ DELETE
  /// Permanent delete. Faculty: own CANCELLED slips. Personnel: CANCELLED or
  /// REJECTED slips.
  Future<void> deletePassSlip(UserModel actor, String id) => _run(() async {
        if (actor.role == Roles.guard) throw _denied;
        final ref = _slips.doc(id);
        await _db.runTransaction((tx) async {
          final snap = await tx.get(ref);
          if (!snap.exists) {
            throw const AppException('This pass slip no longer exists.');
          }
          final s = PassSlipModel.fromMap(snap.data()!);
          final allowed = actor.role == Roles.faculty
              ? s.status == Status.cancelled && s.createdBy == actor.uid
              : s.status == Status.cancelled || s.status == Status.rejected;
          if (!allowed) {
            throw AppException(
                'A ${Status.label(s.status)} pass slip cannot be deleted. Only cancelled${actor.role == Roles.personnel ? ' or rejected' : ''} records can be removed.');
          }
          tx.delete(ref);
          tx.set(
              _logs.doc(),
              _log(actor, LogAction.deleted, id,
                  'Deleted pass slip $id (${s.studentName}).'));
        });
      }, 'Unable to delete the pass slip. Please try again.');
}
