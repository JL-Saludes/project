import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'firebase_options.dart';
import 'models/user_model.dart';
import 'screens/faculty/faculty_dashboard.dart';
import 'screens/guard/guard_dashboard.dart';
import 'screens/login_screen.dart';
import 'screens/personnel/personnel_dashboard.dart';
import 'services/auth_service.dart';
import 'services/firestore_service.dart';
import 'utils/app_exception.dart';
import 'utils/constants.dart';
import 'widgets/loading_widget.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const CctApp());
}

class CctApp extends StatelessWidget {
  const CctApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CCT Pass Slip System',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: AppColors.primary,
        scaffoldBackgroundColor: AppColors.background,
        appBarTheme: const AppBarTheme(
          backgroundColor: AppColors.primary,
          foregroundColor: Colors.white,
          centerTitle: false,
        ),
      ),
      home: const AuthGate(),
    );
  }
}

/// Decides what to show from auth state + the role stored in Firestore.
/// Users can never pick their own role.
class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: AuthService.instance.authChanges,
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: LoadingWidget());
        }
        final user = snap.data;
        if (user == null) return const LoginScreen();
        return _RoleRouter(key: ValueKey(user.uid), uid: user.uid);
      },
    );
  }
}

class _RoleRouter extends StatefulWidget {
  final String uid;
  const _RoleRouter({super.key, required this.uid});
  @override
  State<_RoleRouter> createState() => _RoleRouterState();
}

class _RoleRouterState extends State<_RoleRouter> {
  late final Stream<UserModel?> _stream =
      FirestoreService.instance.userStream(widget.uid);

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<UserModel?>(
      stream: _stream,
      builder: (context, snap) {
        if (snap.hasError) {
          return _AccessProblem(
              message: friendlyError(snap.error!,
                  fallback: 'Unable to load your account. Please try again.'));
        }
        if (snap.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: LoadingWidget(message: 'Loading account…'));
        }
        final u = snap.data;
        if (u == null || !u.hasValidRole) {
          return const _AccessProblem(
              message:
                  'Your account has no assigned role. Contact the administrator.');
        }
        switch (u.role) {
          case Roles.faculty:
            return FacultyDashboard(user: u);
          case Roles.personnel:
            return PersonnelDashboard(user: u);
          default:
            return GuardDashboard(user: u);
        }
      },
    );
  }
}

class _AccessProblem extends StatelessWidget {
  final String message;
  const _AccessProblem({required this.message});

  @override
  Widget build(BuildContext context) => Scaffold(
        body: EmptyState(
          icon: Icons.lock_outline,
          title: 'Access unavailable',
          message: message,
          action: FilledButton(
              onPressed: AuthService.instance.signOut,
              child: const Text('Sign out')),
        ),
      );
}
