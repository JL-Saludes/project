// PLACEHOLDER. Running `flutterfire configure` regenerates this file with
// your real Firebase project values and overwrites this stub.
import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static const FirebaseOptions currentPlatform = FirebaseOptions(
    apiKey: 'REPLACE_ME',
    appId: 'REPLACE_ME',
    messagingSenderId: 'REPLACE_ME',
    projectId: 'cct-pass-slip-56f8e',
  );
}

